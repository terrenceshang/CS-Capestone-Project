class TimeSort:
    def __innit__ (self, arrRoutes, time):
        self.arrRoutes = arrRoutes
        self.time = time

    def orderShortestStart(self, startTime):
        #code to find times for each route
        #code to order Routes from closest start times and shortest durations
        return orderedRoutes

    def orderShortestEnd(self, endTime):
        #code to find times for each route
        #code to order Routes from closest end times and shortest durations
        return orderedRoutes
