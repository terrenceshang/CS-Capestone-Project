class Stations:
    def __innit__ (self):
    #load Stations into array from Files
    self.arrStations = [amount of Stations]

    def findStation(self, stationName):
        for i in self.arrStations:
            if self.arrStations[i] == stationName:
                return True
        return False



